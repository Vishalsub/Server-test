// #include <rclcpp/rclcpp.hpp>
// #include <moveit/move_group_interface/move_group_interface.hpp>


// int main(int argc, char** argv)
// {
//     rclcpp::init(argc, argv);
//     auto node = rclcpp::Node::make_shared("so101_move_cpp");

//     // Use this node for logging
//     rclcpp::executors::SingleThreadedExecutor executor;
//     executor.add_node(node);

//     // Create MoveGroupInterface
//     moveit::planning_interface::MoveGroupInterface move_group(node, "arm"); 

//     // Create a plan object
//     moveit::planning_interface::MoveGroupInterface::Plan plan;

//     // Set a target pose
//     geometry_msgs::msg::Pose target_pose;
//     target_pose.orientation.w = 1.0;
//     target_pose.position.x = 0.2;
//     target_pose.position.y = 0.0;
//     target_pose.position.z = 0.2;
//     move_group.setPoseTarget(target_pose);

//     // Plan to the target
//     auto result = move_group.plan(plan);

//     if (result == moveit::core::MoveItErrorCode::SUCCESS)
//     {
//         RCLCPP_INFO(node->get_logger(), "Planning successful, executing...");
//         move_group.execute(plan);
//     }
//     else
//     {
//         RCLCPP_ERROR(node->get_logger(), "Planning failed!");
//     }

//     rclcpp::shutdown();
//     return 0;
// }


// #include <rclcpp/rclcpp.hpp>
// #include <moveit/move_group_interface/move_group_interface.hpp>
// #include <moveit_visual_tools/moveit_visual_tools.h>
// #include <thread>

// int main(int argc, char **argv)
// {
//     rclcpp::init(argc, argv);
//     auto node = rclcpp::Node::make_shared("so101_move_cpp");

//     // Logger
//     auto const logger = rclcpp::get_logger("so101_move_cpp");

//     // Spin executor in separate thread (needed for MoveItVisualTools)
//     rclcpp::executors::SingleThreadedExecutor executor;
//     executor.add_node(node);
//     std::thread spinner([&executor]() { executor.spin(); });

//     using moveit::planning_interface::MoveGroupInterface;
//     MoveGroupInterface move_group_interface(node, "arm");

//     // Initialize MoveItVisualTools
//     namespace rvt = rviz_visual_tools;
//     moveit_visual_tools::MoveItVisualTools visual_tools(
//         node, "base", rvt::RVIZ_MARKER_TOPIC, move_group_interface.getRobotModel());
//     visual_tools.deleteAllMarkers();
//     visual_tools.loadRemoteControl();

//     // Helper lambdas for visualization
//     auto draw_title = [&visual_tools](const std::string &text) {
//         Eigen::Isometry3d text_pose = Eigen::Isometry3d::Identity();
//         text_pose.translation().z() = 1.0;
//         visual_tools.publishText(text_pose, text, rvt::WHITE, rvt::XLARGE);
//     };

//     auto prompt = [&visual_tools](const std::string &text) {
//         visual_tools.prompt(text);
//     };

//     auto draw_trajectory_tool_path = [&visual_tools,
//                                       jmg = move_group_interface.getRobotModel()->getJointModelGroup("arm")](auto const &trajectory) {
//         visual_tools.publishTrajectoryLine(trajectory, jmg);
//     };

//     // Set target pose
//     geometry_msgs::msg::Pose target_pose;
//     target_pose.orientation.w = 1.0;
//     target_pose.position.x = 0.2;
//     target_pose.position.y = 0.0;
//     target_pose.position.z = 0.2;
//     move_group_interface.setPoseTarget(target_pose);

//     // Visual prompt before planning
//     prompt("Press 'Next' in RViz to plan");
//     draw_title("Planning");
//     visual_tools.trigger();

//     // Plan
//     moveit::planning_interface::MoveGroupInterface::Plan plan;
//     bool success = static_cast<bool>(move_group_interface.plan(plan));

//     if (success)
//     {
//         draw_trajectory_tool_path(plan.trajectory);
//         visual_tools.trigger();
//         prompt("Press 'Next' in RViz to execute");
//         draw_title("Executing");
//         visual_tools.trigger();
//         move_group_interface.execute(plan);
//     }
//     else
//     {
//         draw_title("Planning Failed!");
//         visual_tools.trigger();
//         RCLCPP_ERROR(logger, "Planning failed!");
//     }

//     // Shutdown
//     rclcpp::shutdown();
//     spinner.join();
//     return 0;
// }


#include <rclcpp/rclcpp.hpp>
#include <moveit/move_group_interface/move_group_interface.hpp>
#include <moveit/planning_scene_interface/planning_scene_interface.hpp>
#include <geometry_msgs/msg/pose.hpp>

int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    auto node = rclcpp::Node::make_shared("so101_pick_place_box");

    using moveit::planning_interface::MoveGroupInterface;
    using moveit::planning_interface::PlanningSceneInterface;

    MoveGroupInterface arm_group(node, "arm");
    PlanningSceneInterface planning_scene_interface;

    // Increase planning reliability
    arm_group.setPlanningTime(10.0);
    arm_group.setNumPlanningAttempts(10);

    // --------------------------------
    // 1. Add the box to the scene
    // --------------------------------
    moveit_msgs::msg::CollisionObject box;
    box.header.frame_id = "base";  // Ensure matches your robot base frame
    box.id = "box1";

    shape_msgs::msg::SolidPrimitive primitive;
    primitive.type = primitive.BOX;
    primitive.dimensions = {0.10, 0.05, 0.05};  // 10cm x 5cm x 5cm

    geometry_msgs::msg::Pose box_pose;
    box_pose.orientation.w = 1.0;
    box_pose.position.x = 0.04;
    box_pose.position.y = -0.24;
    box_pose.position.z = 0.0;

    box.primitives.push_back(primitive);
    box.primitive_poses.push_back(box_pose);
    box.operation = box.ADD;

    planning_scene_interface.applyCollisionObject(box);
    RCLCPP_INFO(node->get_logger(), "Added box to planning scene.");

    // --------------------------------
    // 2. Move above the box (Pick Pose)
    // --------------------------------
    geometry_msgs::msg::Pose pick_pose = box_pose;
    pick_pose.position.z += 0.15;  // 15cm above the box

    arm_group.setPoseTarget(pick_pose);
    moveit::planning_interface::MoveGroupInterface::Plan plan;
    bool success = static_cast<bool>(arm_group.plan(plan));

    if (success)
    {
        RCLCPP_INFO(node->get_logger(), "Moving to pick pose...");
        arm_group.execute(plan);
    }
    else
    {
        RCLCPP_ERROR(node->get_logger(), "Failed to plan to pick pose.");
        rclcpp::shutdown();
        return 0;
    }

    // --------------------------------
    // 3. Attach the box (simulate grasp)
    // --------------------------------
    arm_group.attachObject(box.id);
    RCLCPP_INFO(node->get_logger(), "Box attached to end effector.");

    // --------------------------------
    // 4. Move to a place location
    // --------------------------------
    geometry_msgs::msg::Pose place_pose;
    place_pose.orientation.w = 1.0;
    place_pose.position.x = 0.3;
    place_pose.position.y = 0.0;
    place_pose.position.z = 0.25;

    arm_group.setPoseTarget(place_pose);
    success = static_cast<bool>(arm_group.plan(plan));
    if (success)
    {
        RCLCPP_INFO(node->get_logger(), "Moving to place pose...");
        arm_group.execute(plan);
    }
    else
    {
        RCLCPP_ERROR(node->get_logger(), "Failed to plan to place pose.");
        rclcpp::shutdown();
        return 0;
    }

    // --------------------------------
    // 5. Detach the box (simulate release)
    // --------------------------------
    arm_group.detachObject(box.id);
    RCLCPP_INFO(node->get_logger(), "Box detached (released).");

    rclcpp::shutdown();
    return 0;
}
